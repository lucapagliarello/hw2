<?php

namespace Illuminate\Foundation;

/**
 * @deprecated use ViteException
 */
class ViteManifestNotFoundException extends ViteException
{
    //
}
