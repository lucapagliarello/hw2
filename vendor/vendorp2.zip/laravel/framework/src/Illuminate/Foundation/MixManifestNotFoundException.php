<?php

namespace Illuminate\Foundation;

use Exception;

class MixManifestNotFoundException extends Exception
{
    //
}
