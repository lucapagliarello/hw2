<?php

namespace Illuminate\Foundation;

use Exception;

class ViteException extends Exception
{
    //
}
