<?php

namespace Illuminate\Foundation;

use Exception;

class MixFileNotFoundException extends Exception
{
    //
}
