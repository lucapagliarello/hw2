<?php

namespace Laravel\Prompts\Exceptions;

use RuntimeException;

class NonInteractiveValidationException extends RuntimeException
{
    //
}
